
	Sintaxis de jQuery:
		La sintaxis de jQuery está hecha a medida para seleccionar 
	elementos HTML y realizar alguna acción en los elementos.

	La sintaxis básica es: 
	$( selector ).acción ()

	Un signo $ para definir / acceder a jQuery
	Un ( selector ) para "consultar (o buscar)" elementos HTML
	Una acción jQuery () que se realizará en los elementos
	Ejemplos:

	$(this).hide() - oculta el elemento actual.

	$("p").hide() - oculta todos los elementos <p>.

	$(".test").hide() - Oculta todos los elementos con class = "test".

	$("#test").hide() - oculta el elemento con id = "test".

	Con jQuery atravesar, puede moverse fácilmente hacia arriba (antepasados), hacia abajo (descendientes) y hacia los lados (hermanos) en el árbol, comenzando desde el elemento seleccionado (actual). Este movimiento se denomina atravesar (o moverse a través) del árbol DOM.

	Ejemplos de selectores
$ ("*") Selecciona todos los elementos
$ (this) Selecciona el elemento HTML actual
$ ("p.intro") Selecciona todos los elementos <p> con class = "intro"
$ ("p: first") Selecciona el primer elemento <p>
$ ("ul li: first") Selecciona el primer elemento <li> del primer <ul>
$ ("ul li: primer hijo") Selecciona el primer elemento <li> de cada <ul>
$ ("[href]") Selecciona todos los elementos con un atributo href
$ ("a [target = '_ blank']") Selecciona todos los elementos <a> con un valor de atributo de destino igual a "_blank"
$ ("a [target! = '_ blank']") Selecciona todos los elementos <a> con un valor de atributo de destino NO igual a "_blank"
$ (": button") Selecciona todos los elementos <button> y <input> de type = "button"
$ ("tr: even") Selecciona todos los elementos pares <tr>
$ ("tr: odd") Selecciona todos los elementos <tr> impares














