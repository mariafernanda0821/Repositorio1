


$(document).ready(function(){
    $("#abrir-Iniciar").click(function(){
        $('.modal').css("display", "Block");
    }); 
    $("#abrir").click(function(){
        $('.modal-Iniciar').css("display", "Block");
    }); 
   $(".close").click(function(){
        $('.modal-Iniciar').css("display", "none");
        $('.modal').css("display", "none");
    });
   
	$(".flex").click(function(e){
		console.log(e.target)
		if(e.target == ".flex"){
			$('.modal-Iniciar').css("display", "none");
			$('.modal').css("display", "none");
		}
    });
});


/*
$(document).ready( function(){
    $(".BotonP").click(function(){
		//$("Carrito.html").add('36110', $(this).closest('.BotonP'));
		$(["Carrito.html"]).clone("h1").add("h1")
	})
});
*/

$(document).ready(function() {
	//Botón de acción del acordeón
	$('.BotonProductos').click(function() {
		//Elimina la clase on de todos los botones
		$('.BotonProductos').removeClass('on');
			//Añade la clase on en el botón
			$(this).addClass('on');
			//Abre el slide
			$(this).next().slideToggle('slow');
		// }
	 });

	// Cerramos todo el contenido al cargar la página
    $('.ContenedorInterno').hide();

});








/*
buscador 

$(document).ready(function(){
  $("#myInput").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTable tr").filter(function() {
			$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
  	});
});

*/


/*
<a class= "bnt btn-cart" onclick=
	"Carrito.add('36110', $(this).closest('.button-group').find('input[name=\'quantify\']').val()">
</a>
*/

/*
$(document).ready(function() {

	//Botón de acción del acordeón
	$('.BotonProductos').click(function() {

		//Elimina la clase on de todos los botones
		$('.BotonProductos').removeClass('on');

		//Plegamos todo el contenido que esta abierto
	 	$('.ContenedorInterno').slideUp('slow');

		//Si el siguiente slide no esta abierto lo abrimos
		if($(this).next().is(':hidden') == true) {

			//Añade la clase on en el botón
			$(this).addClass('on');

			//Abre el slide
			$(this).next().slideDown('slow');
		 }

	 });

	// Cerramos todo el contenido al cargar la página
	$('.ContenedorInterno').hide();

});



*/ 

