La directiva ng-app define una aplicación AngularJS.

La directiva ng-model vincula el valor de los controles HTML (entrada, selección, área de texto) a los datos de la aplicación.

La directiva ng-bind vincula los datos de la aplicación a la vista HTML.