
Las variables de JavaScript son contenedores para almacenar valores de datos.
Identificadores de JavaScript
	Todas las variables de JavaScript deben identificarse con nombres únicos .
	Estos nombres únicos se denominan identificadores .
	Los identificadores pueden ser nombres cortos (como xey) o nombres más descriptivos (edad, suma, volumen total).
	Las reglas generales para construir nombres para variables (identificadores únicos) son:
		Los nombres pueden contener letras, dígitos, guiones bajos y signos de dólar.
		Los nombres deben comenzar con una letra
		Los nombres también pueden comenzar con $ y _ (pero no los usaremos en este tutorial)
		Los nombres distinguen entre mayúsculas y minúsculas (y e Y son variables diferentes)
		Las palabras reservadas (como las palabras clave de JavaScript) no se pueden usar como nombres

para concatenar palabras +=


document.get

	Funciones: 
	Usando el ejemplo anterior, se toCelsiusrefiere al objeto de función y se toCelsius()refiere al resultado de la función.

	para acceder a los objetos es de la siguiente manera 
	Acceder a las propiedades del objeto
Puede acceder a las propiedades del objeto de dos formas:

objectName.propertyName
o

objectName["propertyName"]

La esta palabra clave
En una definición de función, se thisrefiere al "propietario" de la función.

En el ejemplo anterior, thises el objeto persona que "posee" la fullNamefunción.

En otras palabras, this.firstNamesignifica la firstNamepropiedad de este objeto .

Acceso a métodos de objeto
Se accede a un método de objeto con la siguiente sintaxis:

objectName.methodName()
Ejemplo
name = person.fullName();


el objetName= nombre del objeto
Lea más sobre la this palabra clave en JS this Keyword .



DOCUMENTACION

activeElement =>	Devuelve el elemento actualmente enfocado en el documento.
addEventListener()	 => Adjunta un controlador de eventos al documento
adoptNode()	=> Adopta un nodo de otro documento
anchors =>  Devuelve una colección de todos los elementos <a> en el documento que tienen un atributo de nombre
applets => 	Devuelve una colección de todos los elementos <applet> en el documento
baseURI => 	Devuelve el URI base absoluto de un documento
body	=>  Establece o devuelve el cuerpo del documento (el elemento <body>)
close() =>	Cierra el flujo de salida previamente abierto con document.open ()
cookie =>	Devuelve todos los pares de cookies de nombre / valor en el documento
charset	Deprecated. =>  Utilice characterSet en su lugar. Devuelve la codificación de caracteres del documento.
characterSet =>	Devuelve la codificación de caracteres para el documento
createAttribute()	=> Crea un nodo de atributo
createComment()	=> Crea un nodo Comentario con el texto especificado
createDocumentFragment() =>	Crea un nodo DocumentFragment vacío