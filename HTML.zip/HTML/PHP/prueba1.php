<?php>
//comentarios =>  en php las variables si se distingue en las mayusculas y minusculas
#comentarios

variables en php empieza con $[nombres de las variables]

La echodeclaración de PHP se usa a menudo para enviar datos a la pantalla.
$txt = "W3Schools.com";
echo "I love " . $txt . "!"; para llamar una variable por pantalla se debe  colocar de la siguiente
 manera. variable .

Una variable declarada fuera de una función tiene un ALCANCE GLOBAL y solo se puede acceder fuera de 
una función
Una variable declarada dentro de una función tiene un ALCANCE LOCAL y solo se puede acceder dentro 
de esa función
las variables no se reinician 
on PHP, hay dos formas básicas de obtener resultados: echoy print.
echoy printson más o menos iguales. Ambos se utilizan para enviar datos a la pantalla.

Las diferencias son pequeñas: echono tiene valor de retorno, mientras que printtiene un valor
 de retorno de 1, por lo que se puede usar en expresiones. echopuede tomar múltiples parámetros 
 (aunque tal uso es raro) mientras que printpuede tomar un argumento. echoes ligeramente más rápido
  que print.

  La función PHP var_dump () devuelve el tipo y valor de datos:
  La strlen()función PHP devuelve la longitud de una cadena
  La str_word_count()función PHP cuenta el número de palabras en una cadena.
  La strrev()función PHP invierte una cadena.
  La strpos()función PHP busca un texto específico dentro de una cadena. Si se encuentra una 
  coincidencia, la función devuelve la posición del carácter de la primera coincidencia.
   Si no se encuentra ninguna coincidencia, devolverá FALSE.
   La str_replace()función PHP reemplaza algunos caracteres con otros caracteres en una cadena.
   NaN son las siglas de Not a Number.
   is_numeric () se puede usar para encontrar si una variable es numérica. La función devuelve
    verdadero si la variable es un número o una cadena numérica, falso en caso contrario.
    Crear una constante PHP
Para crear una constante, use la define()función.

Sintaxis
define(name, value, case-insensitive)
Parámetros:

nombre : especifica el nombre de la constante
valor : especifica el valor de la constante
no distingue entre mayúsculas y minúsculas : especifica si el nombre de la constante no debe 
distinguir entre mayúsculas y minúsculas. El valor predeterminado es falso
Sintaxis
function functionName() {
  code to be executed;
}

?>